"""This module implements histogram-based gradient boosting estimators.

The implementation is a port from pygbm which is itself strongly inspired
from LightGBM.
"""
